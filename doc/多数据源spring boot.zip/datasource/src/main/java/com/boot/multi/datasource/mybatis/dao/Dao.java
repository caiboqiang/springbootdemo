package com.boot.multi.datasource.mybatis.dao;

/**
 * @author Xingyu Sun
 * @date 2018/6/4 14:23
 */
public interface Dao {
}
