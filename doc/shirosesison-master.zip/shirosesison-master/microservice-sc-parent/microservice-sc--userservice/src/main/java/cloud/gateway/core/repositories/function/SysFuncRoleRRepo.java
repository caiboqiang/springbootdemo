package cloud.gateway.core.repositories.function;

import cloud.gateway.core.models.function.SysFuncRoleR;
import cloud.gateway.core.repositories.base.BaseDaoRepo;

/**
 * Created by Administrator on 2017/11/9.
 */
public interface SysFuncRoleRRepo extends BaseDaoRepo<SysFuncRoleR> {

}
