package microservice.sc.util;

public class RequestObject {
	private String pCode;
	public String getpCode() {
		return pCode;
	}
	public void setpCode(String pCode) {
		this.pCode = pCode;
	}
}
