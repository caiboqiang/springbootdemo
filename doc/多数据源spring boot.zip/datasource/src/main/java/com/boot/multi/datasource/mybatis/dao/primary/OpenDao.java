package com.boot.multi.datasource.mybatis.dao.primary;

import com.boot.multi.datasource.mybatis.dao.Dao;

/**
 * @author Xingyu Sun
 * @date 2018/6/4 14:24
 */
public interface OpenDao extends Dao {

}
